<?php

return [

	'votingStartTime' => '2020-12-14 06:00:00',
	'votingEndTime' => '2020-12-16 10:00:00',
	'viewResults' => 1,
	'viewVotingCards' => 1,
];