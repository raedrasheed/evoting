<?php

return [

	'__version__' => '2.0',
	'__difficulty_target' => 5,
	'__number_of_nodes' => 11,
	'__sleepTime' => 2, /* Seconds */
	'votingStartTime' => '2021-01-20 00:00:00',
	'votingEndTime' => '2021-01-31 23:59:59',
	'viewResults' => 1,
	'viewVotingCards' => 1,
	'remindMessage' => 'نذكركم بالمشاركة بانتخابات نقابة العاملين على الرابط https://election.iugaza.edu.ps ... اللجنة الانتخابية',
	//'remindMessage' => 'عزيزي المقترع يحق لك انتخاب رئيس واحد وأربع أكاديميين وأربع  إداريين كحد أقصى...   اللجنة الانتخابية',
	'maintenance' => '0',
	'listsInRawWidth' => '3',
	'listsInRawWidthInVoteCards' => '3',
	'viewListImageInVoteCards' => 0,
	'resultForEachList' => 1,

];