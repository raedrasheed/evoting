<?php

return [
    'title' =>  'نظام الإنتخاب الإلكتروني',
	'app_dir' =>  'rtl',
];