<?php

return [
    'title' =>  'GoVote.Live',
	'app_dir' =>  'ltr',
];