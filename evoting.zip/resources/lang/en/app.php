<?php

return [
    'title' =>  'eVoting System',
	'app_dir' =>  'ltr',
];