<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PoolOfVote extends Model
{
    //
}
