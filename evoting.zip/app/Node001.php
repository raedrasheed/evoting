<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Node001 extends Model
{
    //
}
