<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Node007Controller extends Controller
{
    //
}
