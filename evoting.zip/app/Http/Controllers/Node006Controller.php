<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Node006Controller extends Controller
{
    //
}
