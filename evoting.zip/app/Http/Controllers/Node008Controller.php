<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Node008Controller extends Controller
{
    //
}
