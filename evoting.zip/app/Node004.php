<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Node004 extends Model
{
    //
}
