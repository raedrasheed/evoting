<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Node008 extends Model
{
    //
}
