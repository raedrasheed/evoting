<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Node007 extends Model
{
    //
}
