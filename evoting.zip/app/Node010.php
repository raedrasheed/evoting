<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Node010 extends Model
{
    //
}
