<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Node005 extends Model
{
    //
}
