<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(trans('app.title')); ?></title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
			@font-face {
			  font-family: siteFont;
			  src: url(<?php echo e(asset("css/fonts/DroidKufi-Regular.ttf")); ?>);
			}
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: siteFont, sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 42px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 16px;
                font-weight: 600;
                /*letter-spacing: .1rem;*/
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 10px;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>"><?php echo e(__('Home')); ?></a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
				 <div class="title m-b-md">
                    <img src="<?php echo e(asset('imgs/iug_logo.png')); ?>" width="40%">
                </div>
                <div class="title m-b-md">
                    <?php echo e(trans('app.title')); ?>

                </div>

                <div class="links">
                    <p><a><?php echo e(__('Election Commission')); ?></a></p>
                    <p><a><?php echo e(__('Islamic University of Gaza')); ?></a></p>
                </div>
            </div>
        </div>
    </body>
</html>
<?php /**PATH /home/election/evoting/resources/views/welcome.blade.php ENDPATH**/ ?>