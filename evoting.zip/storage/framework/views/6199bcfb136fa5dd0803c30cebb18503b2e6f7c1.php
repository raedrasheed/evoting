<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->role == 1): ?>
	<div class="container">		
		<div class="row justify-content-center">
			<div class="col-md-8">
				<div class="card">
					<div class="card-header">
						Settings						
					</div>
					<div class="card-body">
						<form method="POST" action="<?php echo e(route('editSettings')); ?>">
                        <?php echo csrf_field(); ?>
							 <div class="form-group row">
								<label for="systemName" class="col-md-4 col-form-label text-md-right"><?php echo e(__('System Name')); ?></label>

								<div class="col-md-6">
									<input id="systemName" type="text" class="form-control <?php if ($errors->has('systemName')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('systemName'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="systemName" value="<?php echo e(old('systemName')); ?>" required autocomplete="systemName" autofocus>

									<?php if ($errors->has('systemName')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('systemName'); ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($message); ?></strong>
										</span>
									<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
								</div>
							</div>
							<div class="form-group row">
								<label for="votingTimeStart" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Voting Time Start')); ?></label>

								<div class="col-md-6">
									<input id="votingTimeStart" type="text" class="form-control <?php if ($errors->has('votingTimeStart')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('votingTimeStart'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="votingTimeStart" value="<?php echo e(old('votingTimeStart')); ?>" required autocomplete="votingTimeStart" autofocus>

									<?php if ($errors->has('votingTimeStart')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('votingTimeStart'); ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($message); ?></strong>
										</span>
									<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
								</div>
							</div>
							<div class="form-group row">
								<label for="votingTimeFinish" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Voting Time Finish')); ?></label>

								<div class="col-md-6">
									<input id="votingTimeFinish" type="text" class="form-control <?php if ($errors->has('votingTimeFinish')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('votingTimeFinish'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="votingTimeFinish" value="<?php echo e(old('votingTimeFinish')); ?>" required autocomplete="votingTimeFinish" autofocus>

									<?php if ($errors->has('votingTimeFinish')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('votingTimeFinish'); ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($message); ?></strong>
										</span>
									<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
								</div>
							</div>
							<div class="form-group row">
								<label for="numberOfNodes" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Number Of Nodes')); ?></label>

								<div class="col-md-6">
									<input id="numberOfNodes" type="text" class="form-control <?php if ($errors->has('numberOfNodes')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('numberOfNodes'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="numberOfNodes" value="<?php echo e(old('numberOfNodes')); ?>" required autocomplete="numberOfNodes" autofocus>

									<?php if ($errors->has('numberOfNodes')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('numberOfNodes'); ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($message); ?></strong>
										</span>
									<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
								</div>
							</div>
							<div class="form-group row">
								<label for="numberOfNomineeTypes" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Number Of Nominee Types')); ?></label>

								<div class="col-md-6">
									<input id="numberOfNomineeTypes" type="text" class="form-control <?php if ($errors->has('numberOfNomineeTypes')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('numberOfNomineeTypes'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="numberOfNomineeTypes" value="<?php echo e(old('numberOfNomineeTypes')); ?>" required autocomplete="numberOfNomineeTypes" autofocus>

									<?php if ($errors->has('numberOfNomineeTypes')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('numberOfNomineeTypes'); ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($message); ?></strong>
										</span>
									<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
								</div>
							</div>
							<div class="form-group row">
								<label for="showResults" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Show Results')); ?></label>

								<div class="col-md-6">
									<input id="showResults" type="text" class="form-control <?php if ($errors->has('showResults')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('showResults'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="showResults" value="<?php echo e(old('showResults')); ?>" required autocomplete="showResults" autofocus>

									<?php if ($errors->has('showResults')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('showResults'); ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($message); ?></strong>
										</span>
									<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
								</div>
							</div>
							
							<div class="form-group row mb-0">
								<div class="col-md-6 offset-md-4">
									<button type="submit" class="btn btn-primary btn-block">
										<?php echo e(__('Save')); ?>

									</button>
								</div>
							</div>
						</form>	
					</div>
				
				</div>
			</div>
		</div>	
	</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\evoting\resources\views/settings.blade.php ENDPATH**/ ?>