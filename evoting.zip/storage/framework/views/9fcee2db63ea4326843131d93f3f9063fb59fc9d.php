<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->role == 1): ?>
	<?php ($defualtPhoto = 'imgs/photos/photo.jpg'); ?>
	<div class="container">		
		<div class="row justify-content-center">
			<div class="col-md-8">
				<div class="card">
					<div class="card-header"><b><?php echo e(__('Add/Edit Nominee')); ?><bb></div>
					<div class="card-body">
						<form method="POST" action="<?php echo e(route('saveNominee')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
							<input type="hidden" id="id" name="id" value="<?php if(isset($nominee)): ?><?php echo e($nominee->id); ?><?php else: ?><?php echo e(__('0')); ?><?php endif; ?>"/>
							
							<div class="form-group row">
								<label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

								<div class="col-md-8">
									<input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php if(isset($nominee)): ?><?php echo e($nominee->name); ?><?php else: ?><?php echo e(old('name')); ?><?php endif; ?>" required autocomplete="name" autofocus>

									<?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($message); ?></strong>
										</span>
									<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
								</div>
							</div>
							 <div class="form-group row">
								<label for="photo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Photo')); ?></label>

								<div class="col-md-8">
									<label for="photo"> 
										<img id="photoImg"  src="<?php if(isset($nominee)): ?><?php echo e(asset($nominee->photo)); ?><?php else: ?><?php echo e(old('photo')); ?><?php endif; ?>" style="width:100px;height:100px; border: solid 2px #000;" onerror="this.onerror=null;this.src='<?php echo e(asset($defualtPhoto)); ?>';" />
									</label>
									<input type="file" style="display:none;" id="photo" name="photo" class="form-control <?php if ($errors->has('photo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photo'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="photo" value="<?php if(isset($nominee)): ?><?php echo e($nominee->photo); ?><?php else: ?><?php echo e(old('photo')); ?><?php endif; ?>" onChange="loadImage(this);">
									<?php if ($errors->has('photo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photo'); ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($message); ?></strong>
										</span>
									<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
								</div>
							</div>
							<div class="form-group row">
								<label for="type" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nomination Type')); ?></label>

								<div class="col-md-8">
									<select id="type" class="js-example-basic-single form-control <?php if ($errors->has('type')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('type'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="type" value="<?php if(isset($nominee)): ?><?php echo e($nominee->type); ?><?php else: ?><?php echo e(old('type')); ?><?php endif; ?>" required autocomplete="type" autofocus>
										<option value="0"><?php echo e(__('Chose Option')); ?>...</option>
										<option value="1" <?php if(isset($nominee)): ?> <?php if($nominee->type == 1): ?> <?php echo e(_('selected')); ?> <?php endif; ?> <?php else: ?> <?php echo e(old('type')); ?><?php endif; ?> ><?php echo e(__('Presidential')); ?></option>
										<option value="2" <?php if(isset($nominee)): ?> <?php if($nominee->type == 2): ?> <?php echo e(_('selected')); ?> <?php endif; ?> <?php else: ?> <?php echo e(old('type')); ?><?php endif; ?> ><?php echo e(__('Academic')); ?></option>
										<option value="3" <?php if(isset($nominee)): ?> <?php if($nominee->type == 3): ?> <?php echo e(_('selected')); ?> <?php endif; ?> <?php else: ?> <?php echo e(old('type')); ?><?php endif; ?> ><?php echo e(__('Administrative')); ?></option>
									</select>
									<?php if ($errors->has('type')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('type'); ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($message); ?></strong>
										</span>
									<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
								</div>
							</div>
							<div class="form-group row">
								<label for="description" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

								<div class="col-md-8">
									<input id="description" type="text" class="form-control <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="description" value="<?php if(isset($nominee)): ?><?php echo e($nominee->description); ?><?php else: ?><?php echo e(old('description')); ?><?php endif; ?>" required autocomplete="description" autofocus>

									<?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($message); ?></strong>
										</span>
									<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
								</div>
							</div>
							
							<div class="form-group row mb-0">
								<div class="col-md-6">
									<button type="submit" class="btn btn-primary btn-block">
										<?php echo e(__('Save')); ?>

									</button>
								</div>
								<div class="col-md-6">
									<a class="btn btn-secondary btn-block" href="<?php echo e(route('nominees')); ?>">
										<?php echo e(__('Cancel')); ?>

									</a>
								</div>
							</div>
						</form>	
					</div>
				</div>
			</div>
		</div>	
	</div>
	<script type="text/javascript">
		function loadImage(input) {
			if (input.files && input.files[0]) {
				var reader = new FileReader();

				reader.onload = function (e) {
					$('#photoImg')
						.attr('src', e.target.result)
						.width(96)
						.height(96);
				};

				reader.readAsDataURL(input.files[0]);
			}
		}
		
	</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\evoting\resources\views/addEditNominee.blade.php ENDPATH**/ ?>