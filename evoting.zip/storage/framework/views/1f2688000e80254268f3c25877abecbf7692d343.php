<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->role == 1): ?>
	<div class="container">		
		<div class="row justify-content-center">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
					<b><?php echo e(__('Logs')); ?></b>
						<div class="<?php echo e((App::isLocale('ar') ? 'to-left' : 'to-right')); ?>">
							<a href="<?php echo e(route('clearLogs')); ?>"><img class="m-icon" src="<?php echo e(asset('imgs/delete.png')); ?>" title="Clear All Logs" /></a>
						</div>
					</div>
					<div class="card-body">
						<table class="data-table">	
							<thead>
								<tr>
									<th><?php echo e(__('ID')); ?></th>
									<th><?php echo e(__('User')); ?></th>
									<th><?php echo e(__('Action')); ?></th>
									<th><?php echo e(__('Time')); ?></th>
									<th><?php echo e(__('IP')); ?></th>
																		
									<th><?php echo e(__('Delete')); ?></th>								
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr class="raw-shadow">
										<td><?php echo e($log->id); ?></td>
										<td><?php echo e($log->user->name); ?></td>
										<td><?php echo e($log->action); ?></td>
										<td><?php echo e($log->time); ?></td>
										<td><?php echo e($log->ip); ?></td>
																			
										<th><a href="<?php echo e(route('deleteLog', [ 'id'=> $log->id ])); ?>"><img class="m-icon" src="<?php echo e(asset('imgs/delete.png')); ?>" title="<?php echo e(__('Delete Log')); ?>" /></a></th>								
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
							</tbody>
						</table>
						<p>
							<?php echo $logs->links(); ?>

						</p>
					</div>
				</div>
			</div>
		</div>	
	</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\evoting\resources\views/logs.blade.php ENDPATH**/ ?>