<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->role == 1): ?>
	<div class="container">		
		<div class="row justify-content-center">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						Statistics
						<div class="to-right">
							Blockchain Status: 
							
								<?php if( $fine ): ?><span style="color:#38c172;font-weight:600;text-decoration:none;"> Fine</span>
								<?php else: ?> <span style="color:#e74c3c;font-weight:600;text-decoration:none;"> Error,</span>
									<a href="#"><span style="color:#38c172;font-weight:600;text-decoration:none;"> [ Refine ]</a>
								<?php endif; ?>
							
						</div>
					</div>
					<div class="card-body">
						
						<p>Blockchain:</p>
						<?php $prevBlock=0; ?>
						<?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<p>
							<?php 
								if(!$prevBlock){
									$block_header = json_decode($block->block_header, true);
									if(hash('sha256',$block->vote) != $block_header["vote_hash"]){
										echo "<span style='color:#e74c3c;'>";										
									}else{
										echo "<span style='color:#38c172;'>";
									}										
								}else{
									$block_header = json_decode($block->block_header, true);
									if(hash('sha256',$block->vote) != $block_header["vote_hash"]){
										echo "<span style='color:#e74c3c;'>";
									}elseif(hash('sha256',$prevBlock->block_header) != $block_header["previous_block_hash"]){
										echo "<span style='color:#e74c3c;'>";
									}else{
										echo "<span style='color:#38c172;'>";
									}										
								}
								$prevBlock = $block;
							?>
							<b>Block[<?php echo e($block->id); ?>]:</b> <?php echo e($block); ?>

							</span>
							</p>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
					</div>
				</div>
			</div>
		</div>	
	</div>
	
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\evoting\resources\views/statistics.blade.php ENDPATH**/ ?>