<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->role == 1 || Auth::user()->role == 2): ?>
	<?php ($defualtPhoto = 'imgs/photo.jpg'); ?>
	<div class="container">		
		<div class="row justify-content-center">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
					<b><?php echo e(__('Results Statistics')); ?></b>			
					</div>
					<div class="card-body">
					<div class="form-group row">						
						<div class="stat-circle stat-main col-md-4" data-count="<?php echo e($allVoters); ?>" data-percent-count="<?php echo e($allVoters); ?>">
							<div class="stat-count-circle">0							 
							</div>
							<div class="stat-main-container">
							<?php echo e(__('All Voters')); ?>

							</div>							
						</div>
						<div class="stat-circle stat-main col-md-4" data-count="<?php echo e($totalVotes); ?>" data-percent-count="<?php echo e($totalVotes); ?>">
							<div class="stat-count-circle">0							 
							</div>
							<div class="stat-main-container">
							<?php echo e(__('Total Votes')); ?>

							</div>							
						</div>
						<div class="stat-circle stat-main col-md-4" data-count="<?php echo e($votingPrecentage); ?>" data-percent-count="<?php echo e($votingPrecentage); ?>">
							<div class="stat-percent-circle">0						 
							</div>
							<div class="stat-main-container">
							<?php echo e(__('Voting Precentage')); ?>

							</div>							
						</div>
					<div class="form-group row">
					</div>
						<div class="stat-circle stat-main col-md-4" data-count="<?php echo e($correctVotes); ?>" data-percent-count="<?php echo e($correctVotes); ?>">
							<div class="stat-count-circle">0							 
							</div>
							<div class="stat-main-container">
							<?php echo e(__('Correct Votes')); ?>

							</div>							
						</div>
						<div class="stat-circle stat-main col-md-4" data-count="<?php echo e($incorrectVotes); ?>" data-percent-count="<?php echo e($incorrectVotes); ?>">
							<div class="stat-count-circle">0							 
							</div>
							<div class="stat-main-container">
							<?php echo e(__('Incorrect Votes')); ?>

							</div>							
						</div>
					</div>
					</div>
				</div>	
			</div>
		</div>
		<div class="row justify-content-center">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header"><b><?php echo e(__('Presidential Vote Results')); ?></b></div>
					<div class="card-body">
						<div class="stat-holder">	
						
							<?php ($votes = 0); ?>
							<?php ($votesPercentage = 0); ?>
							<?php $__currentLoopData = json_decode($nomineesVotesJSON, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomineeVotes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($nomineeVotes['type'] == 1): ?>
									<?php ($votes = $nomineeVotes['votes']); ?>
									<?php if($totalVotes == 0): ?>
										<?php ($votesPercentage = 0); ?>
									<?php else: ?>
										<?php ($votesPercentage = $nomineeVotes['votes'] / $totalVotes * 100); ?>
									<?php endif; ?>
									<div class="stat-bar cf" data-percent="<?php echo e($votesPercentage); ?>%" data-percent-count="<?php echo e($votes); ?>" style="<?php echo e((App::isLocale('ar') ? 'right' : 'left')); ?>:8em;">
										<span class="stat-label" style="<?php echo e((App::isLocale('ar') ? 'right' : 'left')); ?>:-11em;">	
											 <img src="<?php echo e(asset($nomineeVotes['photo'])); ?>" alt="Avatar" style="width:45px; height:45px;border: solid 2px #3d3d3d;" onerror="this.onerror=null;this.src='<?php echo e(asset($defualtPhoto)); ?>';">
											 <?php echo e($nomineeVotes['name']); ?>

										</span>
									</div>	
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
						</div>
					</div>
				</div>	
			</div>
		</div>
		<div class="row justify-content-center">
			<div class="col-md-12">				
				<div class="card">
					<div class="card-header"><b><?php echo e(__('Member Vote Results')); ?></b></div>
					<div class="card-body">
						<div class="stat-holder">
							<?php ($votes = 0); ?>
							<?php ($votesPercentage = 0); ?>
							
							<?php $__currentLoopData = json_decode($nomineesVotesJSON, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomineeVotes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($nomineeVotes['type'] == 2 || $nomineeVotes['type'] == 3): ?>
									<?php ($votes = $nomineeVotes['votes']); ?>
									<?php if($totalVotes == 0): ?>
										<?php ($votesPercentage = 0); ?>
									<?php else: ?>
										<?php ($votesPercentage = $nomineeVotes['votes'] / $totalVotes * 100); ?>
									<?php endif; ?>
									<div class="stat-bar cf" data-percent="<?php echo e($votesPercentage); ?>%" data-percent-count="<?php echo e($votes); ?>" style="<?php echo e((App::isLocale('ar') ? 'right' : 'left')); ?>:8em;">
										<span class="stat-label" style="<?php echo e((App::isLocale('ar') ? 'right' : 'left')); ?>:-11em;">	
											 <img src="<?php echo e(asset($nomineeVotes['photo'])); ?>" alt="Avatar" style="width:45px;  height:45px;border: solid 2px #3d3d3d;" onerror="this.onerror=null;this.src='<?php echo e(asset($defualtPhoto)); ?>';">
											 <?php echo e($nomineeVotes['name']); ?>

										</span>
									</div>	
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>	
	<script>
		setTimeout(function start() {
		  $(".stat-bar").each(function (i) {
			var $bar = $(this);
			$(this).append('<span class="stat-count" style="<?php echo e((App::isLocale("ar") ? "left" : "right")); ?>:0.25em"></span>');
			$(this).append('<span class="stat-count-pers" style="<?php echo e((App::isLocale("ar") ? "left" : "right")); ?>:-3.2em"></span>');
			setTimeout(function () {
			  $bar.css("width", $bar.attr("data-percent"));
			}, i * 100);
		  });

		  $(".stat-count").each(function () {
			$(this)
			  .prop("Counter", 0)
			  .animate(
				{
				  Counter: $(this).parent(".stat-bar").attr("data-percent-count")
				},
				{
				  duration: 2000,
				  easing: "swing",
				  step: function (now) {
					$(this).text(Math.ceil(now));
				  }
				}
			  );
		  });
		  
		  $(".stat-count-pers").each(function () {
			$(this)
			  .prop("Counter", 0)
			  .animate(
				{
				  Counter: $(this).parent(".stat-bar").attr("data-percent")
				},
				{
				  duration: 2000,
				  easing: "swing",
				  step: function (now) {
					$(this).text((Math.round(now*10)/10) + "%");
				  }
				}
			  );
		  });
		  
		  $(".stat-count-circle").each(function () {
			$(this)
			  .prop("Counter", 0)
			  .animate(
				{
				  Counter: $(this).parent(".stat-circle").attr("data-count")
				},
				{
				  duration: 2000,
				  easing: "swing",
				  step: function (now) {
					$(this).text(Math.ceil(now));
				  }
				}
			  );
		  });
		  
		   $(".stat-percent-circle").each(function () {
			$(this)
			  .prop("Counter", 0)
			  .animate(
				{
				  Counter: $(this).parent(".stat-circle").attr("data-percent-count")
				},
				{
				  duration: 2000,
				  easing: "swing",
				  step: function (now) {
					$(this).text((Math.round(now*10)/10) + "%");
				  }
				}
			  );
		  });
		  
		}, 500);


	</script>
	<script>
	
	</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/election/evoting/resources/views/results.blade.php ENDPATH**/ ?>