<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->role == 1): ?>
	<div class="container">		
		<div class="row justify-content-center">
			<div class="col-md-10">
				<div class="card">
					<div class="card-header">Log</div>
					<div class="card-body">
						<table class="data-table">	
							<thead>
								<tr>
									<th>ID</th>
									<th>User</th>
									<th>Action</th>
									<th>Time</th>
									<th>IP</th>
									<th>Mac Address</th>									
									<th>delete</th>								
								</tr>
							</thead>
							<tbody>
								<tr class="raw-shadow">
									<td>11</td>
									<td>Name son of other Name</td>
									<td>Vote</td>
									<td>21-12-2020 11:37:12</td>
									<td>85.64.145.62</td>
									<td>0C:D2:92:BB:90:55</td>									
									<th><a href="#"><img class="m-icon" src="<?php echo e(asset('imgs/delete.png')); ?>"/></a></th>								
								</tr>
								<tr class="raw-shadow">
									<td>12</td>
									<td>Name son of other Name</td>
									<td>Logout</td>
									<td>21-12-2020 11:37:50</td>
									<td>85.64.145.62</td>
									<td>0C:D2:92:BB:90:55</td>									
									<th><a href="#"><img class="m-icon" src="<?php echo e(asset('imgs/delete.png')); ?>"/></a></th>								
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>	
	</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\evoting\resources\views/log.blade.php ENDPATH**/ ?>