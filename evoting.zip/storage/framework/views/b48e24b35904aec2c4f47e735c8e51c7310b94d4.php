<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->role == 1 || Auth::user()->role == 2): ?>
	<div class="container">		
		<div class="row justify-content-center">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
					<b><?php echo e(__('Voting Cards')); ?>: <?php echo e($noOfVotes); ?> <?php echo e(__('Cards')); ?></b>
						<div class="<?php echo e((App::isLocale('ar') ? 'to-left' : 'to-right')); ?>">
							<?php echo e(__('Blockchain Status')); ?>: 
							
								<?php if( $fine ): ?><span style="color:#38c172;font-weight:600;text-decoration:none;"> <?php echo e(__('Fine')); ?></span>
								<?php else: ?> <span style="color:#e74c3c;font-weight:600;text-decoration:none;"> <?php echo e(__('Error')); ?></span>
								<?php endif; ?>
							
						</div>
					</div>
					<div class="card-body">						
						
						<?php $prevBlock=0; ?>
						<?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
							<?php 
								if(!$prevBlock){
									$block_header = json_decode($block->block_header, true);
									if(hash('sha256',$block->vote) != $block_header["vote_hash"]){
										echo "<div class='card' style='background-color:rgb(255 172 163);'>";										
									}else{
										echo "<div class='card' style='background-color:#EEE;'>";
									}										
								}else{
									$block_header = json_decode($block->block_header, true);
									if(hash('sha256',$block->vote) != $block_header["vote_hash"]){
										echo "<div class='card' style='background-color:rgb(255 172 163);'>";
									}elseif(hash('sha256',$prevBlock->block_header) != $block_header["previous_block_hash"]){
										echo "<div class='card' style='background-color:rgb(255 172 163);'>";
									}else{
										echo "<div class='card' style='background-color:#EEE;'>";
									}										
								}
								$prevBlock = $block;
							?>
							
							<div class="card-header" style="background-color:#666;color:#FFF"><h5><b><?php echo e(__('Card #')); ?>:[<?php echo e($block->id); ?>]<b></h5></div>
							<div class="card-body">
							
								<table style="width:100%;border:none;">
									<tr>
										<td style="vertical-align: top;border:none;">
									
										<table style="width:100%;border:none;">
											<tr>
												<th colspan=2>
												<?php echo e(__('Presidential Nominees')); ?>

												</th>
											</tr>
											
												
												<?php $__currentLoopData = $presidentialNominees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $presidentialNominee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php ( $nomineeID = '' ); ?>
													<?php ( $choice = '' ); ?>
													<?php ( $choiceElement = 'imgs/unchecked.png' ); ?>
													<?php $__currentLoopData = json_decode($block->vote, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voteCard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<?php $__currentLoopData = $voteCard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vCard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>									
															<?php if(number_format($vCard['nomineeID']) == $presidentialNominee->id ): ?>									
																<?php ( $nomineeID = $vCard['nomineeID'] ); ?>
																<?php ( $choice = $vCard['choice'] ); ?>
																<?php break; ?>
															<?php endif; ?>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<?php if($choice == 'true'): ?> 
														<?php ( $choiceElement = 'imgs/checked.png' ); ?>
													<?php endif; ?>		
														<tr class="raw top-bottom-padding-10">
															<td style="vertical-align: top;border:none;width:30px;"><img src="<?php echo e(asset($choiceElement)); ?>" style="width:25px;" /></td>							
															<!--<img class="nominee-photo" src="<?php echo e(asset($presidentialNominee->photo)); ?>"/>-->
															<td style="vertical-align: top;border:none;"><?php echo e($presidentialNominee->name); ?></td>
														</tr>
													
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
							
											
										</table>
										</td>
										<td style="vertical-align: top;border:none;">
										<table style="width:100%;border:none;">
											<tr>
												<th colspan=2>
												<?php echo e(__('Academic Members Nominees')); ?>

												</th>
											</tr>
											
												
												<?php $__currentLoopData = $academicMemberNominees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $academicMemberNominee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php ( $nomineeID = '' ); ?>
													<?php ( $choice = '' ); ?>
													<?php ( $choiceElement = 'imgs/unchecked.png' ); ?>
													<?php $__currentLoopData = json_decode($block->vote, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voteCard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<?php $__currentLoopData = $voteCard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vCard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>									
															<?php if(number_format($vCard['nomineeID']) == $academicMemberNominee->id ): ?>									
																<?php ( $nomineeID = $vCard['nomineeID'] ); ?>
																<?php ( $choice = $vCard['choice'] ); ?>
																<?php break; ?>
															<?php endif; ?>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<?php if($choice == 'true'): ?> 
														<?php ( $choiceElement = 'imgs/checked.png' ); ?>
													<?php endif; ?>		
														<tr class="raw top-bottom-padding-10">
															<td style="vertical-align: top;border:none;width:30px;"><img src="<?php echo e(asset($choiceElement)); ?>" style="width:25px;" /></td>							
															<!--<img class="nominee-photo" src="<?php echo e(asset($academicMemberNominee->photo)); ?>"/>-->
															<td style="vertical-align: top;border:none;"><?php echo e($academicMemberNominee->name); ?></td>
														</tr>
													
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
							
											
										</table>
										</td>
										<td style="vertical-align: top;border:none;">
										<table style="width:100%;border:none;">
											<tr>
												<th colspan=2>
												<?php echo e(__('Administrative Members Nominees')); ?>

												</th>
											</tr>
											
												
												<?php $__currentLoopData = $administrativeMemberNominees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $administrativeMemberNominee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php ( $nomineeID = '' ); ?>
													<?php ( $choice = '' ); ?>
													<?php ( $choiceElement = 'imgs/unchecked.png' ); ?>
													<?php $__currentLoopData = json_decode($block->vote, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voteCard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<?php $__currentLoopData = $voteCard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vCard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>									
															<?php if(number_format($vCard['nomineeID']) == $administrativeMemberNominee->id ): ?>									
																<?php ( $nomineeID = $vCard['nomineeID'] ); ?>
																<?php ( $choice = $vCard['choice'] ); ?>
																<?php break; ?>
															<?php endif; ?>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<?php if($choice == 'true'): ?> 
														<?php ( $choiceElement = 'imgs/checked.png' ); ?>
													<?php endif; ?>		
														<tr class="raw top-bottom-padding-10">
															<td style="vertical-align: top;border:none;width:30px;"><img src="<?php echo e(asset($choiceElement)); ?>" style="width:25px;" /></td>							
															<!--<img class="nominee-photo" src="<?php echo e(asset($administrativeMemberNominee->photo)); ?>"/>-->
															<td style="vertical-align: top;border:none;"><?php echo e($administrativeMemberNominee->name); ?></td>
														</tr>
													
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
							
											
										</table>
										</td>
									</tr>						
								</table>
							</div>
							</div>
							
							
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
	
					</div>
				</div>
				<p>
					<?php echo $blocks->links(); ?>

				</p>
				
			</div>
		</div>	
	</div>
	
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/election/evoting/resources/views/voteCards.blade.php ENDPATH**/ ?>