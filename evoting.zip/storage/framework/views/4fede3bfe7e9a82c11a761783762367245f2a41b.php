<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->role == 1): ?>
	<div class="container">		
		<div class="row justify-content-center">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header"><b><?php echo e(__('Nominees')); ?></b>
						<div class="<?php echo e((App::isLocale('ar') ? 'to-left' : 'to-right')); ?>">
							<a href="<?php echo e(route('addEditNominee', [ 'id'=> 0 ])); ?>"><img class="m-icon" src="imgs/add.png" title="Add New Nominee" /></a>
						</div>
					</div>
					<div class="card-body data-table-div">
						<table class="data-table">	
							<thead>
								<tr>
									<th><?php echo e(__('Photo')); ?></th>
									<th><?php echo e(__('Name')); ?></th>
									<th><?php echo e(__('Nomination Type')); ?></th>
									<th><?php echo e(__('Description')); ?></th>
									<th><?php echo e(__('Edit')); ?></th>
									<th><?php echo e(__('Delete')); ?></th>								
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $nominees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nominee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr class="raw-shadow">
										<th><img class="nominee-photo" src="<?php echo e(asset($nominee->photo)); ?>"/></th>
										<td><?php echo e($nominee->name); ?></td>
										<td><?php if($nominee->type == 1): ?> <?php echo e(__('Presidential')); ?> <?php elseif($nominee->type == 2): ?> <?php echo e(__('Academic')); ?> <?php elseif($nominee->type == 3): ?> <?php echo e(__('Administrative')); ?> <?php endif; ?></td>
										<td><?php echo e($nominee->description); ?></td>
										<th><a href="<?php echo e(route('addEditNominee', [ 'id'=> $nominee->id ])); ?>"><img class="m-icon" src="imgs/edit.png" title="<?php echo e(__('Edit Nominee')); ?>" /></a></th>
										<th><a href="<?php echo e(route('deleteNominee', [ 'id'=> $nominee->id ])); ?>"><img class="m-icon" src="imgs/delete.png" title="<?php echo e(__('Delete Nominee')); ?>"/></a></th>								
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
						
					</div>
				</div>
			</div>
		</div>	
	</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/election/evoting/resources/views/nominees.blade.php ENDPATH**/ ?>