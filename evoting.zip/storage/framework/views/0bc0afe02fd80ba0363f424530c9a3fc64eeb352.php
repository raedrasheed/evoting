<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->role == 1): ?>
	<div class="container">		
		<div class="row justify-content-center">
			<div class="col-md-8">
				<div class="card">
					<div class="card-header">Statistcs</div>
					<div class="card-body">
						Welcome Admin
					</div>
				</div>
			</div>
		</div>	
	</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\evoting\resources\views/statistcs.blade.php ENDPATH**/ ?>