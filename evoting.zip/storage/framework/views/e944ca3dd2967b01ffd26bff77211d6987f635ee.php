<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->role == 1): ?>
	<div class="container">		
		<div class="row justify-content-center">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header"><b><?php echo e(__('Users')); ?></b>
						<div class="<?php echo e((App::isLocale('ar') ? 'to-left' : 'to-right')); ?>">
							<a href="<?php echo e(route('addEditUser', [ 'id'=> 0 ])); ?>" ><img class="m-icon" src="imgs/add.png" title="Add New User"/></a>
						</div>
					</div>
					<div class="card-body data-table-div">
						<table class="data-table">	
							<thead>
								<tr>
									<th><?php echo e(__('Photo')); ?></th>
									<th><?php echo e(__('Outer ID')); ?></th>
									<th><?php echo e(__('Name')); ?></th>
									<th><?php echo e(__('Username')); ?></th>
									<th><?php echo e(__('User Role')); ?></th>
									<th><?php echo e(__('Voted')); ?></th>
									<th><?php echo e(__('Description')); ?></th>
									<th><?php echo e(__('Mobile')); ?></th>
									<th><?php echo e(__('Logs')); ?></th>
									<th><?php echo e(__('Edit')); ?></th>
									<th><?php echo e(__('Delete')); ?></th>								
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr class="raw-shadow">
										<th><img class="nominee-photo" src="<?php echo e(asset($user->photo)); ?>"/></th>
										<td><?php echo e($user->outer_id); ?></td>
										<td><?php echo e($user->name); ?></td>
										<td><?php echo e($user->username); ?></td>
										<td><?php if($user->role == 1): ?> <?php echo e(__('Administrator')); ?> <?php elseif($user->role == 2): ?> <?php echo e(__('Regular')); ?> <?php endif; ?></th>
										<th><?php if($user->voted == 1): ?> <?php echo e(__('Yes')); ?> <?php else: ?> <?php echo e(__('No')); ?> <?php endif; ?></td>
										<td><?php echo e($user->description); ?></td>
										<td><?php echo e($user->mobile); ?></td>
										<th><a href="<?php echo e(route('logs', [ 'id'=> $user->id ])); ?>"><img class="m-icon" src="<?php echo e(asset('imgs/log.png')); ?>" title="<?php echo e(__('Show User Logs')); ?>"/></a></th>
										<th><a href="<?php echo e(route('addEditUser', [ 'id'=> $user->id ])); ?>"><img class="m-icon" src="<?php echo e(asset('imgs/edit.png')); ?>" title="<?php echo e(__('Edit User')); ?>"/></a></th>
										<th><a href="<?php echo e(route('deleteUser', [ 'id'=> $user->id ])); ?>"><img class="m-icon" src="<?php echo e(asset('imgs/delete.png')); ?>" title="<?php echo e(__('Delete User')); ?>"/></a></th>									
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>								
							</tbody>
						</table>
						<p>
							<?php echo $users->links(); ?>

						</p>
					</div>
				</div>
			</div>
		</div>	
	</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/election/evoting/resources/views/users.blade.php ENDPATH**/ ?>