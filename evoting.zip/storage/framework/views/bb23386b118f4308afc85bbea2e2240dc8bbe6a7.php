<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-7MLP61V0H3"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'G-7MLP61V0H3');
    </script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link rel="icon" type="image/png" href="<?php echo e(asset('imgs/govotelive_logo_T.png')); ?>"/>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(trans('app.title')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
	<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
	
	<script src="<?php echo e(asset('js/sweetalert-dev.js')); ?>"></script>
	<link rel="stylesheet" href="<?php echo e(asset('css/sweetalert.css')); ?>">
	<link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet" />
	<script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
	
	
</head>
<body dir="<?php echo e((App::isLocale('ar') ? 'rtl' : 'ltr')); ?>" style="text-align:<?php echo e((App::isLocale('ar') ? 'right' : 'left')); ?>">
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img style="width:50px;" src="<?php echo e(asset('imgs/govotelive_logo_T.png')); ?>"/>
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
					<ul class="nav navbar-nav">
					</ul>
					
					<ul class="navbar-nav">
							<!-- Authentication Links -->
							 <?php $locale = session()->get('locale'); ?>

								<li class="nav-item dropdown">
									<a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
										 <?php switch($locale):
											case ('ar'): ?>
											<img src="<?php echo e(asset('imgs/ar.png')); ?>" width="20px" height="20x"> عربي
											<?php break; ?>											
											<?php default: ?>
											<img src="<?php echo e(asset('imgs/us.png')); ?>" width="20px" height="20x"> English
										<?php endswitch; ?>
										<span class="caret"></span>
									</a>
									<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
										<a class="dropdown-item" href="<?php echo e(url('lang/en')); ?>"><img src="<?php echo e(asset('imgs/us.png')); ?>" width="20px" height="20x"> English</a>
										<a class="dropdown-item" href="<?php echo e(url('lang/ar')); ?>"><img src="<?php echo e(asset('imgs/ar.png')); ?>" width="20px" height="20x"> عربي</a>
										</div>
								</li>
					</ul>
					
                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav <?php echo e((App::isLocale('ar') ? 'ml-auto-right' : 'ml-auto')); ?>">
                        <!-- Authentication Links -->
						  <?php if(auth()->guard()->guest()): ?>
								<li class="nav-item">
									<a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
								</li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php ($defualtPhoto = 'imgs/photos/photo.jpg') ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <img style="width:30px;border-radius: 20px;border:solid 1px #ccc;" src="<?php echo e(asset(Auth::user()->photo)); ?>" onerror="this.onerror=null;this.src='<?php echo e(asset($defualtPhoto)); ?>';"/>
                                    <?php echo e(Auth::user()->name); ?><span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
									<a class="dropdown-item" href="<?php echo e(route('home')); ?>">
                                       <?php echo e(__('Voting Page')); ?>

                                    </a>
									<a class="dropdown-item" href="<?php echo e(route('myProfile')); ?>">
                                       <?php echo e(__('My Profile')); ?>

                                    </a>
									<?php if(Auth::user()->role == 1): ?>
									<a class="dropdown-item" href="<?php echo e(route('nomineeLists')); ?>">
                                       <?php echo e(__('Nominees Lists')); ?>

                                    </a>
									<a class="dropdown-item" href="<?php echo e(route('nominees')); ?>">
                                       <?php echo e(__('Nominees')); ?>

                                    </a>
									<a class="dropdown-item" href="<?php echo e(route('users')); ?>">
                                       <?php echo e(__('Users')); ?>

                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(route('usersAll')); ?>">
                                       <?php echo e(__('All Users')); ?>

                                    </a>
									 <a class="dropdown-item" href="<?php echo e(route('buildBlockchain')); ?>">
                                       <?php echo e(__('Mining Unmined Blocks')); ?> (<?php echo e(App\PoolOfVote::all()->count()); ?>)
                                    </a>
									<a class="dropdown-item" href="<?php echo e(route('sendSMSForAll')); ?>">
                                       <?php echo e(__('Send SMS to non-voting users')); ?>

                                    </a>
									<a class="dropdown-item" href="<?php echo e(route('logs', [ 'id'=> 0 ])); ?>">
                                        <?php echo e(__('Logs')); ?>

                                    </a>
									<a class="dropdown-item" href="<?php echo e(route('blockchainExplorer')); ?>">
                                        <?php echo e(__('Blockchain Explorer')); ?>

                                    </a>
									<?php endif; ?>
									<?php if(Auth::user()->role == 1 || (config('settings.viewVotingCards') &&
										Carbon\Carbon::parse(config('settings.votingStartTime'))->lt(Carbon\Carbon::now()))): ?>
									<a class="dropdown-item" href="<?php echo e(route('voteCards')); ?>">
                                        <?php echo e(__('Vote Cards')); ?>

                                    </a>
									<?php endif; ?>
									<?php if(Auth::user()->role == 1 || (config('settings.viewResults') &&
										Carbon\Carbon::parse(config('settings.votingStartTime'))->lt(Carbon\Carbon::now()))): ?>
									<a class="dropdown-item" href="<?php echo e(route('results')); ?>">
                                        <?php echo e(__('Results')); ?>

                                    </a>
									<?php endif; ?>									
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                
					
				</div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
	<script>
		function myFunction() {
		  var input, filter, table, tr, td, i, txtValue;
		  input = document.getElementById("myInput");
		  filter = input.value.toUpperCase();
		  table = document.getElementById("myTable");
		  tr = table.getElementsByTagName("tr");
		  
		  for (i = 0; i < tr.length; i++) {
			tds = tr[i].getElementsByTagName("td");
			//alert(tds.length);
			for (j = 0; j < tds.length; j++) {
				td = tds[j];
				if (td) {
				  txtValue = td.textContent || td.innerText;
				  if (txtValue.toUpperCase().indexOf(filter) > -1) {
					tr[i].style.display = "";
					break;
				  } else {
					tr[i].style.display = "none";					
				  }
				}  
			}				
		  }
		}
	</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\evoting\resources\views/layouts/app.blade.php ENDPATH**/ ?>